import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression

from Nermodel1 import Vectorizer


def load_model():
    with open("model.pkl", "rb") as f:
        classifier = pickle.load(f)
    return classifier

def predict_ner(model, new_words):
    X_new = Vectorizer().transform(new_words)
    predictions = model.predict(X_new)
    return predictions

if __name__ == "__main__":
    model = load_model()

    new_words = ["பூனை", "நாய்", "வீடு", "மரம்"]
    predictions = predict_ner(model, new_words)

    # Print the predicted entity types for new words
    for word, prediction in zip(new_words, predictions):
        print(f"{word}@@@{prediction}")
