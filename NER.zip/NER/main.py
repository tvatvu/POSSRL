from flask import Flask
import ML as ml
app = Flask(__name__)


@app.route('/karefoNER/<name>')
def home(name):
    print(name)
    result = {}
   # ml.learningPhase()
    ml.isTrainedFlag = True
    output =ml.generatesingleoutput(name)
    #return "generated output! %s" % output
    #
    result['word'] = name
    result['label'] = output[0].split(',')[1]
    # return "generated output! %s" % output
    return result


if __name__ == "__main__":
    app.run()