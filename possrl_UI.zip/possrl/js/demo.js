    	 $(document).ready(function() {
    	     var list = [];

    	     function loadpostagdesc() {
    	         document.getElementById('posdesc').innerHTML = '';
    	         var postagsD = ['Noun[N]',
    	             'Common Noun[NN]',
    	             'Proper Noun[NNP]',
    	             'Nloc Noun[NST]',
    	             'Pronoun[PR]',
    	             'Personal Pronoun[PRP]',
    	             'Reflexive Pronoun[PRF]',
    	             'Relative Pronoun[PRL]',
    	             'Reciprocal Pronoun[PRC]',
    	             'Wh-word Pronoun[PRQ]',
    	             'Demonstrative[DM]',
    	             'Deictic Demonstr ative[DMD]',
    	             'Relative Demonstr ative[DMR]',
    	             'Wh-word Demonstr ative[DMQ]',
    	             'Verb[V]',
    	             'Main Verb[VM]',
    	             'Finite Verb[VF]',
    	             'Nonfinite Verb[VNF]',
    	             'Verbal particip le Verb[VBN]',
    	             'Relative participle Verb[RP]',
    	             'Conditional Verb[COND]',
    	             'Infinitive Verb[VINF]',
    	             'Gerund Verb[VNG]',
    	             'Verbal Noun[NNV]',
    	             'Auxiliary Verb[VAUX]',
    	             'Adjective[JJ]',
    	             'Adverb[RB]',
    	             'Postposition[PSP]',
    	             'Conjunction[CC]',
    	             'Co-ordinator Conjunction[CCD]',
    	             'Subordinator Conjunction[CCS]',
    	             'Default Particles[RPD]',
    	             'Classifier Particles[CL]',
    	             'Interjection Particles[INJ]',
    	             'Intensifier Particles[INTF]',
    	             'Negation Particles[NEG]',
    	             'Quantifiers[QT]',
    	             'General Quantifiers[QTF]',
    	             'Cardinals Quantifiers[QTC]',
    	             'Ordinals Quantifiers[QTO]',
    	             'Residuals[RD]',
    	             'Foreign Residuals[RDF]',
    	             'Symbol Residuals[SYM]',
    	             'Punctuation Residuals[PUNC]',
    	             'Unknown Residuals[UNK]',
    	             'Echowords Residuals[ECH]'
    	         ];
    	         var postags = ['Noun<N>',
    	             'Common Noun<NN>',
    	             'Proper Noun<NNP>',
    	             'Nloc Noun<NST>',
    	             'Pronoun<PR>',
    	             'Personal Pronoun<PRP>',
    	             'Reflexive Pronoun<PRF>',
    	             'Relative Pronoun<PRL>',
    	             'Reciprocal Pronoun<PRC>',
    	             'Wh-word Pronoun<PRQ>',
    	             'Demonstrative<DM>',
    	             'Deictic Demonstr ative<DMD>',
    	             'Relative Demonstr ative<DMR>',
    	             'Wh-word Demonstr ative<DMQ>',
    	             'Verb<V>',
    	             'Main Verb<VM>',
    	             'Finite Verb<VF>',
    	             'Nonfinite Verb<VNF>',
    	             'Verbal particip le Verb<VBN>',
    	             'Relative participle Verb<RP>',
    	             'Conditional Verb<COND>',
    	             'Infinitive Verb<VINF>',
    	             'Gerund Verb<VNG>',
    	             'Verbal Noun<NNV>',
    	             'Auxiliary Verb<VAUX>',
    	             'Adjective<JJ>',
    	             'Adverb<RB>',
    	             'Postposition<PSP>',
    	             'Conjunction<CC>',
    	             'Co-ordinator Conjunction<CCD>',
    	             'Subordinator Conjunction<CCS>',
    	             'Default Particles<RPD>',
    	             'Classifier Particles<CL>',
    	             'Interjection Particles<INJ>',
    	             'Intensifier Particles<INTF>',
    	             'Negation Particles<NEG>',
    	             'Quantifiers<QT>',
    	             'General Quantifiers<QTF>',
    	             'Cardinals Quantifiers<QTC>',
    	             'Ordinals Quantifiers<QTO>',
    	             'Residuals<RD>',
    	             'Foreign Residuals<RDF>',
    	             'Symbol Residuals<SYM>',
    	             'Punctuation Residuals<PUNC>',
    	             'Unknown Residuals<UNK>',
    	             'Echowords Residuals<ECH>'
    	         ];
    	         var s = '';

    	         for (var j in list) {
    	             for (var i = 0; i < postags.length; i++) {
    	                 if (postags[i].endsWith(list[j])) {
    	                     s += '<div>' + postagsD[i] + '</div>';
    	                     i = postags.length;
    	                     break;
    	                 }
    	             }
    	         }

    	         document.getElementById('posdesc').innerHTML += '   <div class="card-body d-flex justify-content-between" style="background-color: #e6ffee;">' + s + '</div> ';
    	     }






    	     $("#poruliSearch").click(function() {
    	         $("#posResult").empty();
    	         $("#srlResult").empty();
    	         list = [];
    	         document.getElementById("resultArea").style.display = 'none';
    	         var poruliValue = document.getElementById("playArea").value;
    	         var postData = {
    	             input: poruliValue
    	         };

    	         // Make an AJAX POST request to the provided URL
    	         $.ajax({
    	             url: 'https://localhost:7079/possrl/post',
    	             type: 'POST',
    	             data: postData,
    	             dataType: 'json',
    	             success: function(data) {

    	                 document.getElementById("resultArea").style.display = 'block';
    	                 getPosTags(data);

    	             },
    	             error: function(xhr, status, error) {
    	                 // Handle errors here
    	                 console.error('Error:', status, error);
    	             }
    	         });
    	     });


    	     function getPOSResult(sentence) {

    	         var L = '';
    	         var results = String(sentence.posTag).split("|");
    	         for (var j = 0; j < results.length; j++) {
    	             if (j == 0) {
    	                 L += '<div class="list-group-item correct" style="padding:5px;"  ><h4>' + results[j] + '</h4></div>';
    	             } else {
    	                 L += '<div class="list-group-item wrong" style="padding:5px;"  ><h4>' + results[j] + '</h4></div>';
    	             }

    	             let annotations = identifyTags(results[j]);
    	             list.push(...annotations);

    	         }
    	         list = [...new Set(list)];
    	         loadpostagdesc();
    	         return '<li class="list-group-item"  style="width: 100%;border:none;outline; padding:0;"><div style="width: 100%; ">' + L + '</div></li>';
    	         //return L;
    	     }

    	     function identifyTags(taggedS) {
    	         taggedS = taggedS.replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    	         return taggedS.match(/<[^>]+>/g);

    	     }





    	     function getSRLResult(sentence, i) {
    	         var L = '',
    	             L1 = '';
    	         var results = String(sentence.srlTag).split("|");
    	         for (var j = 0; j < results.length; j++) {
    	             if (j == 0) {
    	                 L1 += '<div class="list-group-item correct"   ><h4>' + results[j] + '</h4></div>';
    	             } else {
    	                 L1 += '<div class="list-group-item wrong"   ><h4>' + results[j] + '</h4></div>';
    	             }



    	         }


    	         L += '<div id="gr_' + i + '_' + j + '" class="list-group-item "  style="  border:none;"  > <div class="  row" style="border: none; "> <div class=" col"  style="width: 100%;height: 400px;overflow:auto; "><h4> SEMANTIC LABELED </h4>' + L1 + '</div> <div class="col"    style="height: 400px; overflow:auto;margin:10px; "><h4> DECONVERSION </h4>' + getDNCList(sentence.dncList) + '</div></div></div>';

    	         return ' <div  style="width: 100%;">' + L + '</div> ';

    	     }

    	     function getDNCList(dnc1) { //deConvertedSentences
    	         let dnc = dnc1.filter((value, index, self) => {
    	             return self.indexOf(value) === index;
    	         });
    	         var r = '<ul>';
    	         for (var i in dnc) {
    	             r += '<li><h4>' + dnc[i] + '</h4></li>';
    	         }


    	         return r + '</ul>';
    	     }

    	     function getPosTags(sentences) {
    	         for (var i = 0; i < sentences.length; i++) {
    	             var results = sentences[i];

    	             // Generate POS list
    	             var UL = '<div class="right" style=" margin:5px;border-radius:5px; border: 2px solid #80ffaa;"><div  style="padding:5px; border:none;outline:none;"><h3 class="text-dark">சொற்றொடர்: ' + (i + 1) + '</h3></div><ul class="list-group"  style="width: 100%; border:none;outline:none;">' + getPOSResult(results) + '</ul></div>';
    	             $("#posResult").append(UL);

    	             // Generate SRL list
    	             var SL = '<div class="right" style=" margin:5px;border-radius:5px; border: 2px solid #80ffaa;padding:5px;"><div   style="  display: flex; justify-content: space-between;  border:none;outline:none;padding:5px;"><h3 class=" text-dark col">சொற்றொடர்: ' + (i + 1) + '</h3><h3 class="text-dark text-end col"> ' + results.sentenceType + '</h3></div><div class="list-group"  style="width: 100%; border:none;outline:none;padding:0;">' + getSRLResult(results, i) + '</div></div>';
    	             $("#srlResult").append(SL);

    	         }
    	     }



    	 });